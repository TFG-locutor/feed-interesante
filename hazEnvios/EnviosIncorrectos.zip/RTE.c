#include <stdio.h>

int main() {

  printf("%d\n", 3 / 0);
  
  return 0;
}


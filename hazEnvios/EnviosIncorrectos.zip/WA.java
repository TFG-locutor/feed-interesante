public class WA {

	 public static void main(String[] args) {
		  System.out.println("bu");
	 }
}

public class NO {

	 public static void main(String[] args) {
	 }
}

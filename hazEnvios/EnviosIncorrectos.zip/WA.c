#include <stdio.h>

int main() {
  printf("bu\n");
  return 0;
}

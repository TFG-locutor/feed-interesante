public class RTE {

	 public static void main(String[] args) {

		  int[] a = new int[3];

		  System.out.println(a[4]
	 }
}
